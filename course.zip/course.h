/**
 * @file course.h
 * @author Xianzhao Duan (duanx15@mcmaster.ca)
 * @brief This is the header file for course library.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
/**
 * @brief It defines a struct named Course.
 * String name, String code, Student pointer, and the number of total students.
 * 
 */
typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;
/**
 * @brief Declaration of enroll_student function.
 * 
 * @param course 
 * @param student 
 */
void enroll_student(Course *course, Student *student);
/**
 * @brief Declaration of print_course function.
 * 
 * @param course 
 */
void print_course(Course *course);
/**
 * @brief Declaration of top_student function.
 * 
 * @param course 
 * @return Student* 
 */
Student *top_student(Course* course);
/**
 * @brief Declaration of passing function.
 * 
 * @param course 
 * @param total_passing 
 * @return Student* 
 */
Student *passing(Course* course, int *total_passing);


