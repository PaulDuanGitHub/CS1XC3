/**
 * @file student.h
 * @author Xianzhao Duan (duanx15@mcmaster.ca)
 * @brief This is the header file for student library.
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief It defines a struct named Student.
 * String first_name, String last_name, String id, double *grades, and int num_grades.  
 * 
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;
/**
 * @brief Declaration of add_grade function.
 * 
 * @param student 
 * @param grade 
 */
void add_grade(Student *student, double grade);
/**
 * @brief Declaration of average function.
 * 
 * @param student 
 * @return double 
 */
double average(Student *student);
/**
 * @brief Declaration of print_student function.
 * 
 * @param student 
 */
void print_student(Student *student);
/**
 * @brief Declaration of generate_random_student function.
 * 
 * @param grades 
 * @return Student* 
 */
Student* generate_random_student(int grades); 
